//
//  Triplet.swift
//  BookCore
//
//  Created by StephenFang on 2021/4/20.
//

import Foundation

struct Triplet{
  let firstEntity : String
  let secondEntity : String
  let relation: String
}
